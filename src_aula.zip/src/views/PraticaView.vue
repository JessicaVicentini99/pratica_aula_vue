<script>
import Pratica from '@/components/Pratica.vue'

export default {
  components: {Pratica}
}
</script>
<template>
  <div>
    <h1>Pagina de pratica das aulas</h1>
    <b>:)</b>
    <pratica/>
  </div>
</template>
<style>

</style>
