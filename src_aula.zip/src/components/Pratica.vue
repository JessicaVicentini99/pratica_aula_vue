<script>
export default {
  name: 'Pratica',
  data() {
    return {
      msg: 'Hello World',
      numero: 123,
      contador: 0
    }
  },

  methods: {
    incrementarContador() {
      this.contador++
    }
  }
}
</script>
<template>
  <div>
    <h3>Este é um componente</h3>
    <h2>{{msg}}</h2>
    <br>
    <h2>O contador é: {{contador}}</h2>
    <button @click="incrementarContador">
      Incrementar Contador
    </button>

  </div>
</template>
<style>

</style>
